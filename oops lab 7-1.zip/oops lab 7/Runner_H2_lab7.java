/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Runner_H2_lab7 {
    public static void main(String[]args){
        Address r = new Address(3,56,309,"islamabad");
        Person i = new Person("Isac ","Newton ",45,r);
        Book b1 = new Book("Physics","Thomas",i);
        b1.Display();
    }
    
}
