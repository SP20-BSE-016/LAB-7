/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Pizza {
    private String size;
    private int chtop;
    private int ptop;
    private int htop;
    private double costtopping; 
    public Pizza(String s, int chees, int pep, int ham){
        size = s;
        chtop = chees;
        ptop = pep;
        htop = ham;
    }
    public void setsize(String s){
        size = s;
    }
    public String getSize(){
        return size;
    } 
    public void setcheesetop(int chees){
        chtop  = chees;
    }
    public int getcheesetop(){
        return chtop;
    } 
     public void setpeptop(int pep){
        ptop  = pep;
    }
    public int getpeptop(){
        return ptop;
    } 
     public void sethemtop(int ham){
        htop  = ham;
    }
    public int gethemtop(){
        return htop;
    } 
    public double calCost(){
        costtopping = chtop+ptop+htop;
        double cost;
        if(size=="small"){
            cost = 10+2*costtopping;
        }
        else if(size=="medium"){
            cost = 12+2*costtopping;
        }
        else{
            cost = 14+2*costtopping;
        }
        return cost;
    }
    public boolean getDiscription(){
        System.out.println("your ordered is "+ getSize()+" size pizza " + " with " + chtop +" Cheesetoppings , " + ptop + "  pep toppings and with " + htop + "  ham toppings and your bill for this pizza is " + calCost()+"$");
        return true;
    }
}
    class Pizzaorder{
        Pizza p1;
        Pizza p2;
        Pizza p3;
        double count = 0;
        public Pizzaorder(Pizza a, Pizza b,Pizza c){
            p1 = a;
            p2 = b;
            p3 = c;
            System.out.println(p1.getDiscription());
            System.out.println(p2.getDiscription());
            System.out.println(p3.getDiscription());
             System.out.println("your total bill is "+(p1.calCost()+p2.calCost()+p3.calCost())+"$");
            
        }
         public Pizzaorder(Pizza a, Pizza b){
            p1 = a;
            p2 = b;
            System.out.println(p1.getDiscription());
            System.out.println(p2.getDiscription());
             System.out.println("your total bill is "+(p1.calCost()+p2.calCost())+"$");
             
        }
        public Pizzaorder(Pizza a){
            p2 = a;
            count++;
            System.out.println(p3.getDiscription());
             System.out.println("your total bill is "+p2.calCost()+"$");
            
        }
       
            
    
}
