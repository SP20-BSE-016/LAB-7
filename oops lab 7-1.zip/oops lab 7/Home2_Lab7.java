/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Book{
    String Bookname;
    String Pub;
    Person author;
    public Book(String N, String P, Person A){
        Bookname = N;
        Pub = P;
        author  = A;
        
    }
     public void setBookname(String b){
        Bookname = b;
    }
    public String getBookname(){
        return Bookname;
    }
     public void setPublisher(String p){
        Pub = p;
    }
    public String getPublisher(){
        return Pub;
    }
    public void Display(){
        System.out.println(author.Display());
        System.out.println("Book name is " + Bookname +" and it is published by  "+Pub);
    }
    
}
