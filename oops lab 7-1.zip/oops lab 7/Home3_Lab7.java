/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Point {
    Line xcor;
    Line ycor;
    double count;
    public Point(Line a,Line b){
        xcor = a;
        count ++;
        ycor = b;
        count++;
        
    }
    public Point (Line a ){
        xcor = a;
        count++;
    }
    public void setXcor(Line a){
        xcor = a;
    } 
    public Line getXcor(){
        return xcor;
    }
     public void setYcor(Line b){
        ycor = b;
    } 
    public Line getYcor(){
        return ycor;
    }
    public void Display(){
        if(count == 2){
        System.out.println("Length of the first line is "+ xcor.legth() +" and lenght of the second line is  " + ycor.legth());
        }
        else{
            System.out.println("Lenght of the line  is " + xcor.legth());
    }
}
}
    class Line{
        Point start;
        Point end;
        double x1;
        double x2;
        double y1;
        double y2;
        public Line( double c, double d, double e, double f){
           x1 = c;
           x2 = d;
           y1 = e;
           y2 = f;
        }
        public double legth(){
            double a = Math.sqrt(Math.pow((x2-x1),2)+Math.pow((y2-y1), 2));
            return a;
        }
    }
         

