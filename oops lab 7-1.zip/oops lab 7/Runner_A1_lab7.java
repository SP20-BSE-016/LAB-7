/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;

/**
 *
 * @author Cyber World
 */
public class Runner_A1_lab7 {
    public static void main(String[]args){
        Pizza p1 = new Pizza("large", 1,6,4);
        Pizza p3 = new Pizza("medium", 1,2,3);
        Pizzaorder p = new Pizzaorder(p1,p3);
        //p.Calctotal(); 
    }
            
    
}
