/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package h1_lab7;


/**
 *
 * @author Cyber World
 */
public class Runner_H1_lab7 {
    public static void main(String[]args){
        Address a = new Address(5,13,456,"Lahore");
        a.setCity("faisalabad");
        Person p = new Person("Muhammad ","Ali",20,a);
        p.Display();
    }
    
}
